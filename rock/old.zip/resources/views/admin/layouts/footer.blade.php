<div class="footer">
    <div class="pull-right">
        
    </div>
    <div>
        <strong>Copyright</strong> {!!site_name!!} &copy; @php echo date('Y'); @endphp
    </div>
</div>